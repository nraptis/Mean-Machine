//
//  GLoopMixBrew.cpp
//  MeanMachine
//
//  Created by Dragon on 4/29/26.
//

#include "GLoopMixBrew.hpp"
#include "Random.hpp"
#include "TwistFunctional.hpp"

GLoopFragmentComposerInput GLoopMixBrew::BuildComposerInputForNode(const GLoopMixBrewNode &pNode) const {
    GLoopFragmentComposerInput aInput = pNode.mInput;
    if (aInput.mType == GLoopFragmentComposerInputType::kBuffer) {
        aInput.mInputBuffer.Combine(pNode.mOp);
    } else if (aInput.mType == GLoopFragmentComposerInputType::kVariable) {
        aInput.mInputVariable.Combine(pNode.mOp);
    }
    return aInput;
}

GLoopFragmentComposerInputVariable &GLoopMixBrew::PutVariable(GSymbol pSymbol,
                                                               bool pBefore,
                                                              GLoopFragmentComposerCombineOp pOp) {
    GLoopMixBrewNode aNode;
    aNode.mBefore = pBefore;
    aNode.mOp = pOp;
    GLoopFragmentComposerInputVariable aInput(pSymbol, pOp);
    aNode.mInput = aInput.ToInput();
    mNodes.push_back(aNode);
    return mNodes.back().mInput.mInputVariable;
}

GLoopFragmentComposerInputBuffer &GLoopMixBrew::PutBuffer(GSymbol pSymbol,
                                                           bool pBefore,
                                                          GLoopFragmentComposerCombineOp pOp) {
    GLoopMixBrewNode aNode;
    aNode.mBefore = pBefore;
    aNode.mOp = pOp;
    GLoopFragmentComposerInputBuffer aInput(pSymbol, pOp);
    aNode.mInput = aInput.ToInput();
    mNodes.push_back(aNode);
    return mNodes.back().mInput.mInputBuffer;
}

GLoopFragmentComposerInputVariable &GLoopMixBrew::PutVariableAdd(GSymbol pSymbol, bool pBefore) {
    return PutVariable(pSymbol, pBefore, GLoopFragmentComposerCombineOp::kAdd);
}

GLoopFragmentComposerInputVariable &GLoopMixBrew::PutVariableMul(GSymbol pSymbol, bool pBefore) {
    return PutVariable(pSymbol, pBefore, GLoopFragmentComposerCombineOp::kMul);
}

GLoopFragmentComposerInputVariable &GLoopMixBrew::PutVariableXor(GSymbol pSymbol, bool pBefore) {
    return PutVariable(pSymbol, pBefore, GLoopFragmentComposerCombineOp::kXor);
}

GLoopFragmentComposerInputBuffer &GLoopMixBrew::PutBufferAdd(GSymbol pSymbol, bool pBefore) {
    return PutBuffer(pSymbol, pBefore, GLoopFragmentComposerCombineOp::kAdd);
}

GLoopFragmentComposerInputBuffer &GLoopMixBrew::PutBufferMul(GSymbol pSymbol, bool pBefore) {
    return PutBuffer(pSymbol, pBefore, GLoopFragmentComposerCombineOp::kMul);
}

GLoopFragmentComposerInputBuffer &GLoopMixBrew::PutBufferXor(GSymbol pSymbol, bool pBefore) {
    return PutBuffer(pSymbol, pBefore, GLoopFragmentComposerCombineOp::kXor);
}

GLoopMixBrew::GLoopMixBrew() {
    mRandomOrderEnabled = true;
}

bool GLoopMixBrew::IsValidSBox(GSymbol pSymbol) {
    if (pSymbol.mType != GSymbolType::kBuf) {
        return false;
    }
    if (TwistWorkSpace::IsSBox(pSymbol.mSlot) == false) {
        return false;
    }
    return true;
}

void GLoopMixBrew::SetLoopIndex(GSymbol pLoopIndex) {
    mLoopIndex = pLoopIndex;
}

void GLoopMixBrew::SetTarget(GSymbol pTarget, GSymbol pTargetMix) {
    mTarget = pTarget;
    mTargetMix = pTargetMix;
}

void GLoopMixBrew::SetRandomOrderEnabled(bool pState) {
    mRandomOrderEnabled = pState;
}

namespace {
bool Mix64Type1NeedsAmount(const Mix64Type_1 pType) {
    switch (pType) {
        case Mix64Type_1::kGatePrism_1_8:
            return false;
        case Mix64Type_1::kGateRoll_1_1:
        case Mix64Type_1::kGateRoll_1_4:
        case Mix64Type_1::kGateRoll_1_8:
        case Mix64Type_1::kGateTurn_1_1:
        case Mix64Type_1::kGateTurn_1_4:
        case Mix64Type_1::kGateTurn_1_8:
            return true;
        default:
            return false;
    }
}

bool Mix64Type4NeedsAmount(const Mix64Type_4 pType) {
    switch (pType) {
        case Mix64Type_4::kGatePrismA_4_8:
        case Mix64Type_4::kGatePrismB_4_8:
        case Mix64Type_4::kGatePrismC_4_8:
            return false;
        case Mix64Type_4::kGateRoll_4_4:
        case Mix64Type_4::kGateRollA_4_8:
        case Mix64Type_4::kGateRollB_4_8:
        case Mix64Type_4::kGateRollC_4_8:
        case Mix64Type_4::kGateTurn_4_4:
        case Mix64Type_4::kGateTurnA_4_8:
        case Mix64Type_4::kGateTurnB_4_8:
        case Mix64Type_4::kGateTurnC_4_8:
            return true;
        default:
            return false;
    }
}

bool Mix64Type8NeedsAmount(const Mix64Type_8 pType) {
    switch (pType) {
        case Mix64Type_8::kGatePrism_8_8:
            return false;
        case Mix64Type_8::kGateRoll_8_8:
        case Mix64Type_8::kGateTurn_8_8:
            return true;
        default:
            return false;
    }
}
} // namespace

void GLoopMixBrew::SetMix_1_Random(GSymbol pSBoxA) {
    std::vector<Mix64Type_1> aOptions = TwistMix64::GetAll_1();
    Mix64Type_1 aChosenType = Mix64Type_1::kInv;
    if (!aOptions.empty()) {
        aChosenType = Random::Choice(aOptions);
    }
    if (Mix64Type1NeedsAmount(aChosenType)) {
        const std::vector<std::uint64_t> aRotates = {3U, 5U, 7U, 11U};
        SetMix_1(aChosenType, Random::Choice(aRotates), pSBoxA);
    } else {
        SetMix_1(aChosenType, pSBoxA);
    }
}

void GLoopMixBrew::SetMix_4_Random(GSymbol pSBoxA,
                                   GSymbol pSBoxB,
                                   GSymbol pSBoxC,
                                   GSymbol pSBoxD) {
    std::vector<Mix64Type_4> aOptions = TwistMix64::GetAll_4();
    Mix64Type_4 aChosenType = Mix64Type_4::kInv;
    if (!aOptions.empty()) {
        aChosenType = Random::Choice(aOptions);
    }
    if (Mix64Type4NeedsAmount(aChosenType)) {
        const std::vector<std::uint64_t> aRotates = {3U, 5U, 7U, 11U};
        SetMix_4(aChosenType, Random::Choice(aRotates), pSBoxA, pSBoxB, pSBoxC, pSBoxD);
    } else {
        SetMix_4(aChosenType, pSBoxA, pSBoxB, pSBoxC, pSBoxD);
    }
}

void GLoopMixBrew::SetMix_8_Random(GSymbol pSBoxA,
                                   GSymbol pSBoxB,
                                   GSymbol pSBoxC,
                                   GSymbol pSBoxD,
                                   GSymbol pSBoxE,
                                   GSymbol pSBoxF,
                                   GSymbol pSBoxG,
                                   GSymbol pSBoxH) {
    std::vector<Mix64Type_8> aOptions = TwistMix64::GetAll_8();
    Mix64Type_8 aChosenType = Mix64Type_8::kInv;
    if (!aOptions.empty()) {
        aChosenType = Random::Choice(aOptions);
    }
    if (Mix64Type8NeedsAmount(aChosenType)) {
        const std::vector<std::uint64_t> aRotates = {3U, 5U, 7U, 11U};
        SetMix_8(aChosenType, Random::Choice(aRotates), pSBoxA, pSBoxB, pSBoxC, pSBoxD, pSBoxE, pSBoxF, pSBoxG, pSBoxH);
    } else {
        SetMix_8(aChosenType, pSBoxA, pSBoxB, pSBoxC, pSBoxD, pSBoxE, pSBoxF, pSBoxG, pSBoxH);
    }
}

void GLoopMixBrew::SetMix_1(Mix64Type_1 pMixType, GSymbol pSBoxA) {
    mMix64Family = Mix64Family::k1;
    mMix64Type1 = pMixType;
    mMix64Type4 = Mix64Type_4::kInv;
    mMix64Type8 = Mix64Type_8::kInv;
    mMix64UseAmount = false;
    mMix64Amount = 0U;
    mMixSBoxA = pSBoxA;
    mMixSBoxB.Invalidate();
    mMixSBoxC.Invalidate();
    mMixSBoxD.Invalidate();
    mMixSBoxE.Invalidate();
    mMixSBoxF.Invalidate();
    mMixSBoxG.Invalidate();
    mMixSBoxH.Invalidate();
}

void GLoopMixBrew::SetMix_4(Mix64Type_4 pMixType,
                            GSymbol pSBoxA,
                            GSymbol pSBoxB,
                            GSymbol pSBoxC,
                            GSymbol pSBoxD) {
    mMix64Family = Mix64Family::k4;
    mMix64Type1 = Mix64Type_1::kInv;
    mMix64Type4 = pMixType;
    mMix64Type8 = Mix64Type_8::kInv;
    mMix64UseAmount = false;
    mMix64Amount = 0U;
    mMixSBoxA = pSBoxA;
    mMixSBoxB = pSBoxB;
    mMixSBoxC = pSBoxC;
    mMixSBoxD = pSBoxD;
    mMixSBoxE.Invalidate();
    mMixSBoxF.Invalidate();
    mMixSBoxG.Invalidate();
    mMixSBoxH.Invalidate();
}

void GLoopMixBrew::SetMix_8(Mix64Type_8 pMixType,
                            GSymbol pSBoxA,
                            GSymbol pSBoxB,
                            GSymbol pSBoxC,
                            GSymbol pSBoxD,
                            GSymbol pSBoxE,
                            GSymbol pSBoxF,
                            GSymbol pSBoxG,
                            GSymbol pSBoxH) {
    mMix64Family = Mix64Family::k8;
    mMix64Type1 = Mix64Type_1::kInv;
    mMix64Type4 = Mix64Type_4::kInv;
    mMix64Type8 = pMixType;
    mMix64UseAmount = false;
    mMix64Amount = 0U;
    mMixSBoxA = pSBoxA;
    mMixSBoxB = pSBoxB;
    mMixSBoxC = pSBoxC;
    mMixSBoxD = pSBoxD;
    mMixSBoxE = pSBoxE;
    mMixSBoxF = pSBoxF;
    mMixSBoxG = pSBoxG;
    mMixSBoxH = pSBoxH;
}

void GLoopMixBrew::SetMix_1(Mix64Type_1 pMixType, std::uint64_t pAmount, GSymbol pSBoxA) {
    SetMix_1(pMixType, pSBoxA);
    mMix64UseAmount = true;
    mMix64Amount = pAmount;
}

void GLoopMixBrew::SetMix_4(Mix64Type_4 pMixType,
                            std::uint64_t pAmount,
                            GSymbol pSBoxA,
                            GSymbol pSBoxB,
                            GSymbol pSBoxC,
                            GSymbol pSBoxD) {
    SetMix_4(pMixType, pSBoxA, pSBoxB, pSBoxC, pSBoxD);
    mMix64UseAmount = true;
    mMix64Amount = pAmount;
}

void GLoopMixBrew::SetMix_8(Mix64Type_8 pMixType,
                            std::uint64_t pAmount,
                            GSymbol pSBoxA,
                            GSymbol pSBoxB,
                            GSymbol pSBoxC,
                            GSymbol pSBoxD,
                            GSymbol pSBoxE,
                            GSymbol pSBoxF,
                            GSymbol pSBoxG,
                            GSymbol pSBoxH) {
    SetMix_8(pMixType, pSBoxA, pSBoxB, pSBoxC, pSBoxD, pSBoxE, pSBoxF, pSBoxG, pSBoxH);
    mMix64UseAmount = true;
    mMix64Amount = pAmount;
}

GExpr GLoopMixBrew::BuildMixExpr(const GExpr &pInput) const {
    if (mMix64Family == Mix64Family::k1) {
        if (mMix64UseAmount) {
            return GExpr::Mix64_1(pInput, mMix64Type1, mMix64Amount, mMixSBoxA);
        }
        return GExpr::Mix64_1(pInput, mMix64Type1, mMixSBoxA);
    }
    if (mMix64Family == Mix64Family::k4) {
        if (mMix64UseAmount) {
            return GExpr::Mix64_4(pInput, mMix64Type4, mMix64Amount, mMixSBoxA, mMixSBoxB, mMixSBoxC, mMixSBoxD);
        }
        return GExpr::Mix64_4(pInput, mMix64Type4, mMixSBoxA, mMixSBoxB, mMixSBoxC, mMixSBoxD);
    }
    if (mMix64Family == Mix64Family::k8) {
        if (mMix64UseAmount) {
            return GExpr::Mix64_8(pInput, mMix64Type8, mMix64Amount, mMixSBoxA, mMixSBoxB, mMixSBoxC, mMixSBoxD, mMixSBoxE, mMixSBoxF, mMixSBoxG, mMixSBoxH);
        }
        return GExpr::Mix64_8(pInput, mMix64Type8, mMixSBoxA, mMixSBoxB, mMixSBoxC, mMixSBoxD, mMixSBoxE, mMixSBoxF, mMixSBoxG, mMixSBoxH);
    }
    return GExpr();
}

bool GLoopMixBrew::Bake(GAssignType pAssignTypeBefore,
                        GAssignType pAssignTypeAfter,
                        std::vector<GStatement> *pStatementList,
                        std::string *pErrorString) {
    if (pStatementList == nullptr) {
        if (pErrorString != nullptr) {
            *pErrorString = "GLoopMixBrew.Error: Statement list is NULL, how could you allow that?";
        }
        return false;
    }
    
    switch (pAssignTypeBefore) {
        case GAssignType::kSet:
        case GAssignType::kAddAssign:
        case GAssignType::kXorAssign:
            break;
        default:
            if (pErrorString != nullptr) {
                *pErrorString = "GLoopMixBrew.Error: Assignment (before) type must be set, add assign, or xor assign.";
            }
            return false;
    }
    
    switch (pAssignTypeAfter) {
        case GAssignType::kAddAssign:
        case GAssignType::kXorAssign:
            break;
        default:
            if (pErrorString != nullptr) {
                *pErrorString = "GLoopMixBrew.Error: Assignment (after) type must be add assign, or xor assign.";
            }
            return false;
    }
    
    if (mTarget.IsInvalid()) {
        if (pErrorString != nullptr) {
            *pErrorString = "GLoopMixBrew.Error: Target is invalid. Did you call SetTarget(...)?";
        }
        return false;
    }
    
    if (mMix64Family == Mix64Family::k1) {
        if (mMix64Type1 == Mix64Type_1::kInv) {
            if (pErrorString != nullptr) {
                *pErrorString = "GLoopMixBrew.Error: Mix family is k1, but mix type is invalid.";
            }
            return false;
        }
        if (!IsValidSBox(mMixSBoxA)) {
            if (pErrorString != nullptr) {
                *pErrorString = "GLoopMixBrew.Error: Mix family is k1, but s-box A is not valid.";
            }
            return false;
        }
        if (Mix64Type1NeedsAmount(mMix64Type1) && !mMix64UseAmount) {
            if (pErrorString != nullptr) {
                *pErrorString = "GLoopMixBrew.Error: Mix family is k1, selected type requires an amount.";
            }
            return false;
        }
    } else if (mMix64Family == Mix64Family::k4) {
        if (mMix64Type4 == Mix64Type_4::kInv) {
            if (pErrorString != nullptr) {
                *pErrorString = "GLoopMixBrew.Error: Mix family is k4, but mix type is invalid.";
            }
            return false;
        }
        if (!IsValidSBox(mMixSBoxA) || !IsValidSBox(mMixSBoxB) || !IsValidSBox(mMixSBoxC) || !IsValidSBox(mMixSBoxD)) {
            if (pErrorString != nullptr) {
                *pErrorString = "GLoopMixBrew.Error: Mix family is k4, but one or more s-box symbols are not valid.";
            }
            return false;
        }
        if (Mix64Type4NeedsAmount(mMix64Type4) && !mMix64UseAmount) {
            if (pErrorString != nullptr) {
                *pErrorString = "GLoopMixBrew.Error: Mix family is k4, selected type requires an amount.";
            }
            return false;
        }
    } else if (mMix64Family == Mix64Family::k8) {
        if (mMix64Type8 == Mix64Type_8::kInv) {
            if (pErrorString != nullptr) {
                *pErrorString = "GLoopMixBrew.Error: Mix family is k8, but mix type is invalid.";
            }
            return false;
        }
        if (!IsValidSBox(mMixSBoxA) || !IsValidSBox(mMixSBoxB) || !IsValidSBox(mMixSBoxC) || !IsValidSBox(mMixSBoxD) ||
            !IsValidSBox(mMixSBoxE) || !IsValidSBox(mMixSBoxF) || !IsValidSBox(mMixSBoxG) || !IsValidSBox(mMixSBoxH)) {
            if (pErrorString != nullptr) {
                *pErrorString = "GLoopMixBrew.Error: Mix family is k8, but one or more s-box symbols are not valid.";
            }
            return false;
        }
        if (Mix64Type8NeedsAmount(mMix64Type8) && !mMix64UseAmount) {
            if (pErrorString != nullptr) {
                *pErrorString = "GLoopMixBrew.Error: Mix family is k8, selected type requires an amount.";
            }
            return false;
        }
    } else {
        if (pErrorString != nullptr) {
            *pErrorString = "GLoopMixBrew.Error: Mix is invalid. Did you call SetMix_1(...), SetMix_4(...), SetMix_8(...), or random variants?";
        }
        return false;
    }
    
    std::vector<GLoopMixBrewNode> aBeforeList;
    std::vector<GLoopMixBrewNode> aAfterList;
    
    for (const GLoopMixBrewNode &aNode : mNodes) {
        if (aNode.mBefore) {
            aBeforeList.push_back(aNode);
            
        } else {
            aAfterList.push_back(aNode);
        }
    }
    
    if (mRandomOrderEnabled == true) {
        Random::Shuffle(&aBeforeList);
        Random::Shuffle(&aAfterList);
    }
    
    
    if (aBeforeList.size() <= 0) {
        const GExpr aMixExpr = BuildMixExpr(GExpr::Symbol(mTarget));
        if (pAssignTypeBefore == GAssignType::kAddAssign) {
            pStatementList->push_back(GStatement::AddAssign(GTarget::Symbol(mTarget), aMixExpr));
        } else if (pAssignTypeBefore == GAssignType::kXorAssign) {
            pStatementList->push_back(GStatement::XorAssign(GTarget::Symbol(mTarget), aMixExpr));
        } else {
            pStatementList->push_back(GStatement::Assign(GTarget::Symbol(mTarget), aMixExpr));
        }
    } else {
        if (aBeforeList.size() == 1) {
            GLoopFragmentComposer aComposer(mLoopIndex);
            auto aInput = BuildComposerInputForNode(aBeforeList[0]);
            if (!aComposer.AddInput(aInput)) {
                if (pErrorString != nullptr) {
                    *pErrorString = "GLoopMixBrew.Error: Failed to add single before input.";
                }
                return false;
            }
            
            GExpr aExpression;
            
            if (!aComposer.ResolveToStatementsAndExpression(pStatementList,
                                                            aExpression,
                                                            pErrorString)) {
                return false;
            }
            
            const GExpr aMixExpr = BuildMixExpr(aExpression);
            if (pAssignTypeBefore == GAssignType::kAddAssign) {
                pStatementList->push_back(GStatement::AddAssign(GTarget::Symbol(mTarget), aMixExpr));
            } else if (pAssignTypeBefore == GAssignType::kXorAssign) {
                pStatementList->push_back(GStatement::XorAssign(GTarget::Symbol(mTarget), aMixExpr));
            } else {
                pStatementList->push_back(GStatement::Assign(GTarget::Symbol(mTarget), aMixExpr));
            }
            
        } else {
            GLoopFragmentComposer aComposer(mLoopIndex);
            aComposer.SetTarget(mTargetMix);
            
            for (auto &aItem: aBeforeList) {
                auto aInput = BuildComposerInputForNode(aItem);
                if (!aComposer.AddInput(aInput)) {
                    if (pErrorString != nullptr) {
                        *pErrorString = "GLoopMixBrew.Error: Failed to add before composer input.";
                    }
                    return false;
                }
            }
            
            if (!aComposer.Bake(pStatementList,
                                          pErrorString)) {
                return false;
            }
            
            if (aAfterList.size() > 0) {
                
            } else {
                
            }
            
            const GExpr aMixExpr = BuildMixExpr(GExpr::Symbol(mTargetMix));
            if (pAssignTypeBefore == GAssignType::kAddAssign) {
                pStatementList->push_back(GStatement::AddAssign(GTarget::Symbol(mTarget), aMixExpr));
            } else if (pAssignTypeBefore == GAssignType::kXorAssign) {
                pStatementList->push_back(GStatement::XorAssign(GTarget::Symbol(mTarget), aMixExpr));
            } else {
                pStatementList->push_back(GStatement::Assign(GTarget::Symbol(mTarget), aMixExpr));
            }
        }
    }
    
    if (aAfterList.size() > 0) {
        GLoopFragmentComposer aComposer(mLoopIndex);
        for (auto &aItem: aAfterList) {
            auto aInput = BuildComposerInputForNode(aItem);
            if (!aComposer.AddInput(aInput)) {
                if (pErrorString != nullptr) {
                    *pErrorString = "GLoopMixBrew.Error: Failed to add after composer input.";
                }
                return false;
            }
        }
        
        GExpr aAfterExpression;
        if (!aComposer.ResolveToStatementsAndExpression(pStatementList,
                                                        aAfterExpression,
                                                        pErrorString)) {
            return false;
        }
        
        if (pAssignTypeAfter == GAssignType::kAddAssign) {
            pStatementList->push_back(GStatement::AddAssign(GTarget::Symbol(mTarget),
                                                            aAfterExpression));
        } else {
            pStatementList->push_back(GStatement::XorAssign(GTarget::Symbol(mTarget),
                                                            aAfterExpression));
        }
        
    }
    
    return true;
    
}
