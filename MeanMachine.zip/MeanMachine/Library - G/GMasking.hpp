//
//  GMasking.hpp
//  MeanMachine
//

#ifndef GMasking_hpp
#define GMasking_hpp

#include "GSeedProgram.hpp"
#include "TwistMasking.hpp"
#include "Random.hpp"

#include <cstdint>
#include <string>
#include <vector>

class GMasking {
public:
    
    TwistMaskBraidType              GetRandomBrainType() {
        std::vector<TwistMaskBraidType> aList = TwistMasking::GetAllBraidTypes();
        return aList[Random::Get((int)aList.size())];
    }
    
    TwistMaskWeaveType              GetRandomBrainType() {
        std::vector<TwistMaskWeaveType> aList = TwistMasking::GetAllWeaveTypes();
        return aList[Random::Get((int)aList.size())];
    }
    
    bool BakeBraid(TwistMaskBraidType pType,
                   GSymbol pSourceA,
                   GSymbol pSourceB,
                   std::size_t pBufferLength,
                   GSymbol pMask,
                   std::size_t pMaskLength,
                   std::vector<GStatement> *pStatements,
                   std::string *pError) const {
        return BakeBraidCall(pType, pSourceA, pSourceB, pBufferLength, pMask, pMaskLength, pStatements, pError);
    }

    bool BakeBraidA(GSymbol pSourceA,
                    GSymbol pSourceB,
                    std::size_t pBufferLength,
                    GSymbol pMask,
                    std::size_t pMaskLength,
                    std::vector<GStatement> *pStatements,
                    std::string *pError) const {
        return BakeBraid(TwistMaskBraidType::kA, pSourceA, pSourceB, pBufferLength, pMask, pMaskLength, pStatements, pError);
    }

    bool BakeBraidB(GSymbol pSourceA,
                    GSymbol pSourceB,
                    std::size_t pBufferLength,
                    GSymbol pMask,
                    std::size_t pMaskLength,
                    std::vector<GStatement> *pStatements,
                    std::string *pError) const {
        return BakeBraid(TwistMaskBraidType::kB, pSourceA, pSourceB, pBufferLength, pMask, pMaskLength, pStatements, pError);
    }

    bool BakeBraidC(GSymbol pSourceA,
                    GSymbol pSourceB,
                    std::size_t pBufferLength,
                    GSymbol pMask,
                    std::size_t pMaskLength,
                    std::vector<GStatement> *pStatements,
                    std::string *pError) const {
        return BakeBraid(TwistMaskBraidType::kC, pSourceA, pSourceB, pBufferLength, pMask, pMaskLength, pStatements, pError);
    }

    bool BakeWeave(TwistMaskWeaveType pType,
                   GSymbol pSourceA,
                   GSymbol pSourceB,
                   GSymbol pDest,
                   std::size_t pBufferLength,
                   GSymbol pMask,
                   std::size_t pMaskLength,
                   std::vector<GStatement> *pStatements,
                   std::string *pError) const {
        return BakeWeaveCall(pType, pSourceA, pSourceB, pDest, pBufferLength, pMask, pMaskLength, pStatements, pError);
    }

    bool BakeWeaveA(GSymbol pSourceA,
                    GSymbol pSourceB,
                    GSymbol pDest,
                    std::size_t pBufferLength,
                    GSymbol pMask,
                    std::size_t pMaskLength,
                    std::vector<GStatement> *pStatements,
                    std::string *pError) const {
        return BakeWeave(TwistMaskWeaveType::kA, pSourceA, pSourceB, pDest, pBufferLength, pMask, pMaskLength, pStatements, pError);
    }

    bool BakeWeaveB(GSymbol pSourceA,
                    GSymbol pSourceB,
                    GSymbol pDest,
                    std::size_t pBufferLength,
                    GSymbol pMask,
                    std::size_t pMaskLength,
                    std::vector<GStatement> *pStatements,
                    std::string *pError) const {
        return BakeWeave(TwistMaskWeaveType::kB, pSourceA, pSourceB, pDest, pBufferLength, pMask, pMaskLength, pStatements, pError);
    }

    bool BakeWeaveC(GSymbol pSourceA,
                    GSymbol pSourceB,
                    GSymbol pDest,
                    std::size_t pBufferLength,
                    GSymbol pMask,
                    std::size_t pMaskLength,
                    std::vector<GStatement> *pStatements,
                    std::string *pError) const {
        return BakeWeave(TwistMaskWeaveType::kC, pSourceA, pSourceB, pDest, pBufferLength, pMask, pMaskLength, pStatements, pError);
    }

    bool BakeWeaveD(GSymbol pSourceA,
                    GSymbol pSourceB,
                    GSymbol pDest,
                    std::size_t pBufferLength,
                    GSymbol pMask,
                    std::size_t pMaskLength,
                    std::vector<GStatement> *pStatements,
                    std::string *pError) const {
        return BakeWeave(TwistMaskWeaveType::kD, pSourceA, pSourceB, pDest, pBufferLength, pMask, pMaskLength, pStatements, pError);
    }

private:
    static void SetError(std::string *pError,
                         const std::string &pMessage) {
        if (pError != nullptr) {
            *pError = pMessage;
        }
    }

    static std::string BraidToken(const TwistMaskBraidType pType) {
        switch (pType) {
            case TwistMaskBraidType::kA: return "TwistMaskBraidType::kA";
            case TwistMaskBraidType::kB: return "TwistMaskBraidType::kB";
            case TwistMaskBraidType::kC: return "TwistMaskBraidType::kC";
            default: return "TwistMaskBraidType::kA";
        }
    }

    static std::string WeaveToken(const TwistMaskWeaveType pType) {
        switch (pType) {
            case TwistMaskWeaveType::kA: return "TwistMaskWeaveType::kA";
            case TwistMaskWeaveType::kB: return "TwistMaskWeaveType::kB";
            case TwistMaskWeaveType::kC: return "TwistMaskWeaveType::kC";
            case TwistMaskWeaveType::kD: return "TwistMaskWeaveType::kD";
            default: return "TwistMaskWeaveType::kA";
        }
    }

    static bool BakeBraidCall(TwistMaskBraidType pType,
                              GSymbol pSourceA,
                              GSymbol pSourceB,
                              std::size_t pBufferLength,
                              GSymbol pMask,
                              std::size_t pMaskLength,
                              std::vector<GStatement> *pStatements,
                              std::string *pError) {
        if (pStatements == nullptr) {
            SetError(pError, "GMasking output statement list was null.");
            return false;
        }
        if (!pSourceA.IsBuf() || !pSourceB.IsBuf() || !pMask.IsBuf()) {
            SetError(pError, "GMasking braid symbols must be buffer symbols.");
            return false;
        }
        if ((pBufferLength == 0U) || (pMaskLength == 0U)) {
            SetError(pError, "GMasking braid lengths must be non-zero.");
            return false;
        }

        const std::string aLine = "TwistMasking::MaskBraid(" + BraidToken(pType) + ", " +
            BufAliasName(pSourceA.mSlot) + ", " +
            BufAliasName(pSourceB.mSlot) + ", " +
            std::to_string(static_cast<unsigned long long>(pBufferLength)) + "U, " +
            BufAliasName(pMask.mSlot) + ", " +
            std::to_string(static_cast<unsigned long long>(pMaskLength)) + "U);";
        pStatements->push_back(GStatement::RawLine(aLine));
        return true;
    }

    static bool BakeWeaveCall(TwistMaskWeaveType pType,
                              GSymbol pSourceA,
                              GSymbol pSourceB,
                              GSymbol pDest,
                              std::size_t pBufferLength,
                              GSymbol pMask,
                              std::size_t pMaskLength,
                              std::vector<GStatement> *pStatements,
                              std::string *pError) {
        if (pStatements == nullptr) {
            SetError(pError, "GMasking output statement list was null.");
            return false;
        }
        if (!pSourceA.IsBuf() || !pSourceB.IsBuf() || !pDest.IsBuf() || !pMask.IsBuf()) {
            SetError(pError, "GMasking weave symbols must be buffer symbols.");
            return false;
        }
        if ((pBufferLength == 0U) || (pMaskLength == 0U)) {
            SetError(pError, "GMasking weave lengths must be non-zero.");
            return false;
        }

        const std::string aLine = "TwistMasking::MaskWeave(" + WeaveToken(pType) + ", " +
            BufAliasName(pSourceA.mSlot) + ", " +
            BufAliasName(pSourceB.mSlot) + ", " +
            BufAliasName(pDest.mSlot) + ", " +
            std::to_string(static_cast<unsigned long long>(pBufferLength)) + "U, " +
            BufAliasName(pMask.mSlot) + ", " +
            std::to_string(static_cast<unsigned long long>(pMaskLength)) + "U);";
        pStatements->push_back(GStatement::RawLine(aLine));
        return true;
    }
};

#endif /* GMasking_hpp */
