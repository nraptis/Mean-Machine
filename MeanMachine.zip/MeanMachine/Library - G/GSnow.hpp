//
//  GSnow.hpp
//  MeanMachine
//

#ifndef GSnow_hpp
#define GSnow_hpp

#include "GSeedProgram.hpp"

class GSnow {
public:
    bool BakeAES256(GSymbol pSource,
                    GSymbol pDest,
                    std::vector<GStatement> *pStatements,
                    std::string *pError) const {
        return BakeCounterCall("AES256Counter", pSource, pDest, pStatements, pError);
    }

    bool BakeChaCha20(GSymbol pSource,
                      GSymbol pDest,
                      std::vector<GStatement> *pStatements,
                      std::string *pError) const {
        return BakeCounterCall("ChaCha20Counter", pSource, pDest, pStatements, pError);
    }

    bool BakeSha256(GSymbol pSource,
                    GSymbol pDest,
                    std::vector<GStatement> *pStatements,
                    std::string *pError) const {
        return BakeCounterCall("Sha256Counter", pSource, pDest, pStatements, pError);
    }

    bool BakeAria256(GSymbol pSource,
                     GSymbol pDest,
                     std::vector<GStatement> *pStatements,
                     std::string *pError) const {
        return BakeCounterCall("Aria256Counter", pSource, pDest, pStatements, pError);
    }

private:
    static void SetError(std::string *pError,
                         const std::string &pMessage) {
        if (pError != nullptr) {
            *pError = pMessage;
        }
    }

    static bool BakeCounterCall(const char *pMethodName,
                                GSymbol pSource,
                                GSymbol pDest,
                                std::vector<GStatement> *pStatements,
                                std::string *pError) {
        if (pStatements == nullptr) {
            SetError(pError, "GSnow output statement list was null.");
            return false;
        }
        if (!pSource.IsBuf()) {
            SetError(pError, "GSnow source must be a buffer symbol.");
            return false;
        }
        if (!pDest.IsBuf()) {
            SetError(pError, "GSnow destination must be a buffer symbol.");
            return false;
        }
        if (pMethodName == nullptr || pMethodName[0] == '\0') {
            SetError(pError, "GSnow method name was invalid.");
            return false;
        }

        const std::string aLine = std::string("TwistSnow::") + pMethodName + "(" +
            BufAliasName(pSource.mSlot) + ", " +
            BufAliasName(pDest.mSlot) + ");";
        pStatements->push_back(GStatement::RawLine(aLine));
        return true;
    }
};

#endif /* GSnow_hpp */
