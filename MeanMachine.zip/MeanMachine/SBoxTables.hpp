//
//  SBoxTables.hpp
//  MeanMachine
//
//  Created by John Snow on 4/20/26.
//

#ifndef SBoxTables_hpp
#define SBoxTables_hpp

#include <cstdint>
#include <vector>

class GTwistExpander;

class SBoxTables {
public:
    
    static std::vector<std::vector<std::uint8_t>>               Get();
    
    static std::vector<std::uint8_t>                            GetDefaultA();
    static std::vector<std::uint8_t>                            GetDefaultB();
    static std::vector<std::uint8_t>                            GetDefaultC();
    static std::vector<std::uint8_t>                            GetDefaultD();
    
    static void                                                 InjectRandomFour(GTwistExpander *pExpander);
    
};

#endif /* SBoxTables_hpp */
