//
//  TwistCryptoGenerator.cpp
//  MeanMachine
//
//  Created by Dragon on 4/28/26.
//

#include "TwistCryptoGenerator.hpp"
#include <cstring>
#include <algorithm>
#include <inttypes.h>

TwistCryptoGenerator::TwistCryptoGenerator() {
    mExponents[0] = 11;
    mExponents[1] = 13;
    mExponents[2] = 19;
    mExponents[3] = 23;
    mExponents[4] = 254;
    mTablesBuilt = false;
}

void TwistCryptoGenerator::BuildGFTables() {
    
    int aX = 1;
    
    for (int aI = 0; aI < 255; aI++) {
        mExp[aI] = aX;
        mExp[aI + 255] = aX;
        mLog[aX] = aI;
        
        int aNext = aX ^ (aX << 1);
        if (aNext & 0x100) aNext ^= 0x11B;
        
        aX = aNext;
    }
    
    mLog[0] = 0;
    mTablesBuilt = true;
}

std::uint8_t TwistCryptoGenerator::ReadSeed(const std::uint8_t *pSource, int pIndex) {
    return pSource[pIndex & (S_BLOCK - 1)];
}

void TwistCryptoGenerator::BuildMatrix(const std::uint8_t *pSource,
                                int aIndex,
                                std::uint8_t *pMatrix) {
    
    for (int aRow = 0; aRow < 8; aRow++) {
        std::uint8_t aValue = ReadSeed(pSource, aIndex + aRow);
        aValue ^= static_cast<std::uint8_t>((aValue << 1U) | (aValue >> 7U));
        aValue |= (1 << aRow);
        pMatrix[aRow] = aValue;
    }
    for (int aIter = 0; aIter < 16; aIter++) {
        int aA = ReadSeed(pSource, aIndex + aIter) & 7;
        int aB = ReadSeed(pSource, aIndex + aIter + 37) & 7;
        
        if (aA != aB) {
            pMatrix[aA] ^= pMatrix[aB];
        }
    }
    for (int i = 0; i < 8; i++) {
        if (pMatrix[i] == 0) {
            pMatrix[i] = static_cast<std::uint8_t>(1 << i);
        }
    }
}

void TwistCryptoGenerator::ApplyMatrix(const std::uint8_t *pMatrix,
                                const std::uint8_t *pInput,
                                std::uint8_t *pOutput) {
    for (int aIndex = 0; aIndex < 256; aIndex++) {
        std::uint8_t aX = pInput[aIndex];
        std::uint8_t aY = 0;
        for (int aBit = 0; aBit < 8; aBit++) {
            std::uint8_t aMask = pMatrix[aBit] & aX;
            std::uint8_t aParity = static_cast<std::uint8_t>(__builtin_popcount(aMask) & 1U);
            aY |= static_cast<std::uint8_t>(aParity << aBit);
        }
        pOutput[aIndex] = aY;
    }
}

void TwistCryptoGenerator::GenerateCandidate(const std::uint8_t *pSource,
                                             const std::uint8_t *pFeedBack,
                                      int aIndex,
                                      std::uint8_t *pOutput) {
    
    std::uint8_t aMatrix[8];
    BuildMatrix(pSource, aIndex, aMatrix);
    
    std::uint8_t aBase[256];
    for (int aI = 0; aI < 256; aI++) {
        
        std::uint8_t aSeed = ReadSeed(pSource, aIndex);
        
        if (pFeedBack != NULL) {
            aSeed = pFeedBack[aSeed];
        }
        
        std::uint8_t aX = static_cast<std::uint8_t>(aI ^ aSeed);
        
        std::uint8_t aY;

        
        if (aX == 0) {
            aY = 0;
        } else {
            int aLog = mLog[aX];
            aY = mExp[(255 - aLog) % 255];
        }
        
        aBase[aI] = aY;
    }
    
    ApplyMatrix(aMatrix, aBase, pOutput);
    
    std::uint8_t aConstant = ReadSeed(pSource, aIndex + 511);
    
    for (int aI = 0; aI < 256; aI++) {
        pOutput[aI] ^= aConstant;
    }
}

void TwistCryptoGenerator::Make(const std::uint8_t *pSource,
                                     std::uint8_t *pSBoxA,
                                     std::uint8_t *pSBoxB,
                                     std::uint8_t *pSBoxC,
                                std::uint8_t *pSBoxD) {
    Make(pSource,
         pSBoxA,
         pSBoxB,
         pSBoxC,
         pSBoxD,
         NULL,
         NULL,
         NULL,
         NULL);
}

void TwistCryptoGenerator::Make(const std::uint8_t *pSource,
                                std::uint8_t *pSBoxA,
                                std::uint8_t *pSBoxB,
                                std::uint8_t *pSBoxC,
                                std::uint8_t *pSBoxD,
                                std::uint8_t *pExistingSBoxA,
                                std::uint8_t *pExistingSBoxB,
                                std::uint8_t *pExistingSBoxC,
                                std::uint8_t *pExistingSBoxD) {
    
    if (!mTablesBuilt) {
        BuildGFTables();
    }

        for (int aIndex = 0; aIndex < 256; aIndex++) {
            std::uint8_t *aCandidate = mCandidates[aIndex];
            std::uint8_t *aFeedback = NULL;
            GenerateCandidate(pSource, aFeedback, aIndex, aCandidate);
        }
    
    if (pExistingSBoxA != NULL) {
        memcpy(pSBoxA, mCandidates[128], 256);
        memcpy(pSBoxB, mCandidates[129], 256);
        memcpy(pSBoxC, mCandidates[130], 256);
        memcpy(pSBoxD, mCandidates[131], 256);
    } else {
        memcpy(pSBoxA, mCandidates[0], 256);
        memcpy(pSBoxB, mCandidates[1], 256);
        memcpy(pSBoxC, mCandidates[2], 256);
        memcpy(pSBoxD, mCandidates[3], 256);
    }
}


void TwistCryptoGenerator::Salt(const std::uint8_t *pSource,
                                std::uint8_t *pSaltA,
                                std::uint8_t *pSaltB,
                                std::uint8_t *pSaltC,
                                std::uint8_t *pSaltD,
                                std::uint8_t *pSBoxA,
                                std::uint8_t *pSBoxB,
                                std::uint8_t *pSBoxC,
                                std::uint8_t *pSBoxD) {
    memcpy(pSaltA, pSource + (0 * 128), 128);
    memcpy(pSaltB, pSource + (1 * 128), 128);
    memcpy(pSaltC, pSource + (2 * 128), 128);
    memcpy(pSaltD, pSource + (3 * 128), 128);
}

void TwistCryptoGenerator::Salt(const std::uint8_t *pSource,
                                         std::uint8_t *pSaltA,
                                         std::uint8_t *pSaltB,
                                         std::uint8_t *pSaltC,
                                         std::uint8_t *pSaltD,
                                         std::uint8_t *pExistingSaltA,
                                         std::uint8_t *pExistingSaltB,
                                         std::uint8_t *pExistingSaltC,
                                         std::uint8_t *pExistingSaltD,
                                         std::uint8_t *pSBoxA,
                                         std::uint8_t *pSBoxB,
                                         std::uint8_t *pSBoxC,
                                         std::uint8_t *pSBoxD,
                                         std::uint8_t *pSBoxE,
                                         std::uint8_t *pSBoxF,
                                         std::uint8_t *pSBoxG,
                                std::uint8_t *pSBoxH) {
    
    memcpy(pSaltA, pSource + (10 * 128), 128);
    memcpy(pSaltB, pSource + (11 * 128), 128);
    memcpy(pSaltC, pSource + (12 * 128), 128);
    memcpy(pSaltD, pSource + (13 * 128), 128);
}
